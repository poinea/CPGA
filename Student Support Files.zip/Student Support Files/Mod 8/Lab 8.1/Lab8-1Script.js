
	
	getHostAddress:function(orderContext_sys_id){
		gs.info("#### OrderContext sys_id: " + orderContext_sys_id);
		
		var nodeName = this.getNodeName(orderContext_sys_id);
		var nodeId = this.getNodeId(nodeName);
		var cmpVMUtils = new CMPVMUtils();
		var hostAddress = cmpVMUtils.getReachableIp(nodeId);
		gs.info("#### hostAddress : " + hostAddress);

		return hostAddress;
	},

	//Gets the node name (VMname) of a node from an order context
	getNodeName:function(orderContext_sys_id){
		gs.info("#### Getting Node Name!");

		var grOrder = new GlideRecord('sn_cmp_order');
		grOrder.addQuery('sys_id', orderContext_sys_id);
		grOrder.query();
		
		while (grOrder.next()) {
			var orderDataStr = grOrder.getValue('order_form_data');
			var orderData = JSON.parse(orderDataStr);
			var nodeName = orderData.Nginx_Web_Server_VMname;
			gs.info("#### nodeName: " + nodeName);
		}
		return nodeName;
	},

	//Gets the sys_id of the node from sn_cmp_stack_item
	getNodeId:function(nodeName){
		gs.info("#### Getting Node Sys_Id!");
		
		var grStackItem = new GlideRecord('cmdb_ci_vm_instance');
		grStackItem.addQuery('name', nodeName);
		grStackItem.query();
		gs.info("#### StackItem count: " + grStackItem.getRowCount());
		
		while (grStackItem.next()) {
			var nodeId = grStackItem.getDisplayValue("sys_id");
		}
		gs.info("#### nodeId: " + nodeId);
		
		return nodeId;
	},
	
