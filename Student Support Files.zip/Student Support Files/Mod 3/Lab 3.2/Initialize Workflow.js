// get requested_for user_id
workflow.scratchpad.requested_for = current.request.requested_for + '';
setApprovers();


function setApprovers() {
	workflow.scratchpad.managerId = '';

	// retrieve manager of the requester
	var gr = new GlideRecord('sys_user');
	if(gr.get(workflow.scratchpad.requested_for)) {
		workflow.scratchpad.managerId = gr.manager + '';
	}
}
