var AddCustomTagsforVM = Class.create();
AddCustomTagsforVM.prototype = Object.extendsObject(sn_cmp.PolicyExecutionBase, {
	customScript : function(formData){
		// Manipulation of form parameters are supported. Changes in any other attributes
        // will be ignored.
		// The data available for manipulation is as follows:
		// Form Data -  for example: StackName can be accessed through formData.StackName
		// formData.StackName = "MyStack";
		// User Data  - for example: User Id can be accessed through this.parameters.userData
		// if(this.parameter.userData.userId == 'servicenowuserId')
		//this.info("id = " + formData.StackName);
		gs.info("@@@ brefore: CustomTags :"+formData.CustomTags);
		try {
		if(formData.CustomTags && formData.CustomTags != null && formData.CustomTags.trim() != '') {
			gs.info("@@@ : CustomTags :"+formData.CustomTags);
			var custTags = JSON.parse(formData.CustomTags);
//Add custom tags as shown below
			custTags.Environment = 'Prod';
			custTags.SupportTeam ='Server Support';
			custTags.backup = "Yes";
			custTags.AutoStart = "yes";
			formData.CustomTags = JSON.stringify(custTags);
		}
		}catch(e) {
			gs.info("@@@ the error is :"+e);
		}
		
		
		return formData;
	},
	execute: function() {
		if(this.parameters !=  null && this.parameters.formData != null){
        	var inputData = JSON.parse(JSON.stringify(this.parameters.formData));
		    var outputFormData = this.customScript(inputData);
            if( outputFormData != null){
                this.parameters.formData = outputFormData;
            }
       	}
		var output = {};
		output.answer = this.parameters;
		return JSON.stringify(output);
	},
	type : 'AddCustomTagsforVM'
});	

var AddCustomTagsforVMObj = new AddCustomTagsforVM(inputAttributes);
var outputParams = AddCustomTagsforVMObj.execute();
gs.info( "Output of script is = " + outputParams);
