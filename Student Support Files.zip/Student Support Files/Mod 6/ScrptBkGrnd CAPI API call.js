//Snapshot Volume using CAPI API

// setup the general variables needed for the CAPI call
var interfaceName = "CMA AWS StorageExt Interface";
var methodName = "CreateSnapshot";
var version = "1.0";
var endpoint = "";
var providerName = "aws-ebs";
var credentialId = "";                              //sys_id of the Credential object;
var serviceAccount = "";                            //sys_id of the serviceAccount;

// setup variables specific to the CAPI API
var locationName = activityInput.LocationName;      //AWS Datacenter
var volumeId = activityInput.VolumeId;              //AWS assigned Id of the Volume
var description = activityInput.Description;        //User description for the snapshot

// create an object containing the parameters needed  
var getParameters = function() {
                var apiParameters = {
                                "VolumeId": volumeId,
                                "Description": description,
                                "Location": locationName
                    };
                    return apiParameters;
                };
 
var apiParameters = getParameters();
 
// Create CAPI API Executor Object
var capi = new sn_cloud_api.CAPIOrchestratorServiceScript();

// execute the api
var routeID = capi.executeApi(providerName, version, credentialId, interfaceName, methodName, endpoint, new global.JSON().encode(apiParameters), "ScriptBG", serviceAccount, locationName);

