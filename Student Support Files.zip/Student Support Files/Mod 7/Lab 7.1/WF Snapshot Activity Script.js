//Snapshot Activity Script
 
// setup the variables needed for the capi call
var interfaceName = "CMA AWS StorageExt Interface";
var methodName = "CreateSnapshot";
var version = "1.0";
var endpoint = "";
var providerName = "aws-ebs";
 
var locationName = activityInput.LocationName;
var volumeId = activityInput.VolumeId;
var credentialId = activityInput.CredentialId;
var serviceAccountLookup = activityInput.ServiceAccountId;
var description = activityInput.Description;
 
var getParameters = function() {
                var apiParameters = {
                                "VolumeId": volumeId,
                                "Description": description,
                                "Location": locationName
                    };
                    return apiParameters;
                };
 
var apiParameters = getParameters();
 
// Create CAPI API Executor Object
var capi = new sn_cloud_api.CAPIOrchestratorServiceScript();

// execute the api
var routeID = capi.executeApi(providerName, version, credentialId, interfaceName, methodName, endpoint, new global.JSON().encode(apiParameters), "SnapshotWF", serviceAccountLookup, locationName);
 
var capiResponse = new global.CAPIResponse();
var capiResult = capiResponse.getCAPIResponseFromMID(routeID);
 
//gs.info('capiResult--->'+ new global.JSON.decode(routeID));
 
activityOutput.status = capiResult.status;
activityOutput.output = capiResult.output;
