function processResponse(response, cloudServiceAccountId, ldc, correlationId,step, requestorContext) {
	var cloudModelString = [];
	var volumeResponse = global.JSON.parse(response);
	var reqContext = global.JSON.parse(requestorContext);
	var volume = {
		"u_cmdb_ci_aws_storage_volume_snapshot": {
			   "identification": {
					"cmdb_ci_cloud_service_account": {
						"criterion": {
							"object_id": cloudServiceAccountId
						}
					},
					"cmdb_ci_aws_datacenter": {
						"criterion": {
							"object_id": ldc
						}
					},
					"u_cmdb_ci_aws_storage_volume_snapshot": {
						"criterion": {
							"object_id": volumeResponse.snapshotId
						}
					}
				},
				"attributes": {
					"object_id": volumeResponse.snapshotId,
					"name": volumeResponse.snapshotId,
					"state":volumeResponse.state,
					"volume_name":volumeResponse.volumeId,
					"snapshot_id":volumeResponse.snapshotId
				},
				"references" : {}
			}
		};

		cloudModelString.push(volume);
		return global.JSON.stringify(cloudModelString);
	}
