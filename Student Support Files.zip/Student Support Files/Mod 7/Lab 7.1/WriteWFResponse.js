workflow.info('Getting response values');
var capiResponse = 
if (!gs.nil(capiResponse)){
	workflow.info('Response value ' + capiResponse);
	var respObj = global.JSON.parse(capiResponse);
	
	//Add description for the response processor
	respObj.description = '' + workflow.inputs.u_description;
	workflow.scratchpad.cmpresponse = global.JSON.stringify(respObj); 
	workflow.info('Response value desc ' + workflow.scratchpad.cmpresponse);	
}
else {
	workflow.info('Response is null');
	workflow.scratchpad.cmpresponse = {};
}
