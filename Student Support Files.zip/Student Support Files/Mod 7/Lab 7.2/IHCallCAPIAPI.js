(function execute(inputs, outputs) {

// setup the variables needed for the capi call
var interfaceName = 'CMA AWS StorageExt Interface';
var methodName = 'CreateSnapshot';
var version = "1.0";
var endpoint = "";
var providerName = "aws-ebs";

var locationName = inputs['location'];
var volumeId = inputs['volumeId'];
var credentialId = inputs['credentialId'];
var serviceAccountLookup = inputs['serviceAccountId'];
var description = inputs['description'];

var getParameters = function() {
   var apiParameters = {
       "VolumeId": volumeId,
       "Description": description,
       "Location": locationName
   }
   return apiParameters;
};

var apiParameters = getParameters();

// Create CAPI API Executor Object
var capi = new sn_cloud_api.CAPIOrchestratorServiceScript();

// execute the api
var routeID = capi.executeApi(providerName, version, credentialId, interfaceName, methodName, endpoint, new global.JSON().encode(apiParameters), "SnapshotIH", serviceAccountLookup, locationName);

var capiResponse = new global.CAPIResponse();
var capiResult = capiResponse.getCAPIResponseFromMID(routeID);

gs.info('capiResult -->' + capiResult);

outputs['status'] = capiResult.status;
outputs['output'] = capiResult.output;
})(inputs, outputs);