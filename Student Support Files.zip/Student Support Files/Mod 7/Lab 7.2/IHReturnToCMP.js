(function execute(inputs, outputs) {

gs.info('****[CMP] Flow Inputs - ' + JSON.stringify(inputs));
// populate result in the 'sn_cmp_flow_result table to process the response if any
new sn_cmp.CMPFlowDesignStepHandler().populateFlowResult(inputs.correlationid, inputs);
//new sn_cmp_api.BPOrchestratorServiceScript().handleFlowResult(inputs.correlationid, inputs.log, inputs.error)

outputs['result'] = JSON.stringify(inputs);
gs.info('****[CMP] Flow outputs - ' + JSON.stringify(outputs['result']));

})(inputs, outputs);